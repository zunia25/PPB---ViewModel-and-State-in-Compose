ViewModel: untuk multitasking antar aplikasi
